# Fine-tuning Fieldbook: local project
Python 3.11 recommended. Create and activate a virtual environment.
Install a platform-appropriate PyTorch build from https://pytorch.org/get-started/locally/.
Then run: python -m pip install -r requirements.txt
Then: python train.py
Then: python infer.py

The model downloads from Hugging Face on first use; internet and disk space are needed.
The baseline uses float32. Plan several GB of available RAM; CPU works but can be slow.
An NVIDIA GPU is optional. Apple MPS support depends on your PyTorch installation.
No API keys are required for this public model.

30 manually authored synthetic examples: 18 training, 6 validation, 6 test.
This is only a pipeline demonstration. Build a larger representative dataset for actual use.
Check task and language coverage; remove duplicates across splits and group related examples.
No training or dependency integration has been run by the website author; verify locally.
Pinned teaching versions intentionally differ from the newest library releases.
Keep the same base model and tokenizer revision when loading an adapter.
Fine-tuning does not guarantee improvement. Review results.json and inspect actual errors.
