"""Tiny LoRA teaching experiment. Run: python train.py
Not a production dataset or a promise of improved accuracy.
"""
import json
from pathlib import Path
import torch
from datasets import Dataset
from transformers import (AutoTokenizer, AutoModelForCausalLM,
                          Trainer, TrainingArguments, set_seed)
from peft import LoraConfig, get_peft_model

set_seed(42)
MODEL_ID = "Qwen/Qwen2.5-0.5B-Instruct"
# Keep revision fixed to a Hub commit for stricter reproducibility.
tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
tokenizer.pad_token = tokenizer.eos_token
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID, torch_dtype=torch.float32
)
# Float32 is a simple CPU/MPS/CUDA baseline, but uses more memory.
# Trainer moves the model to the available device.
model.config.use_cache = False

SYSTEM = "Classify the support request. Reply with BILLING, ACCOUNT, or TECHNICAL only."
def prompt_ids(text):
    return tokenizer.apply_chat_template(
        [{"role": "system", "content": SYSTEM},
         {"role": "user", "content": text}],
        tokenize=True, add_generation_prompt=True,
    )

def encode(row):
    prefix = prompt_ids(row["text"])
    answer = tokenizer(row["label"], add_special_tokens=False)["input_ids"]
    answer += [tokenizer.eos_token_id]
    ids = prefix + answer
    if len(ids) > 256:
        raise ValueError("Example exceeds 256 tokens; shorten it or raise the limit.")
    padding = 256 - len(ids)
    return {
        "input_ids": ids + [tokenizer.pad_token_id] * padding,
        "attention_mask": [1] * len(ids) + [0] * padding,
        "labels": [-100] * len(prefix) + answer + [-100] * padding,
    }

rows = [json.loads(line) for line in Path("samples.jsonl").read_text().splitlines() if line.strip()]
assert all(r["label"] in {"BILLING", "ACCOUNT", "TECHNICAL"} for r in rows)
assert len({r["text"] for r in rows}) == len(rows), "Duplicate request"
splits = {s: [r for r in rows if r["split"] == s]
          for s in ("train", "validation", "test")}
assert all(splits.values()), "Every split must contain examples"
data = {s: Dataset.from_list(rs).map(encode, remove_columns=["text", "label", "split"])
        for s, rs in splits.items()}

@torch.inference_mode()
def predict(text):
    model.eval()
    device = next(model.parameters()).device
    ids = torch.tensor([prompt_ids(text)], device=device)
    out = model.generate(input_ids=ids, attention_mask=torch.ones_like(ids),
                         max_new_tokens=8, do_sample=False,
                         pad_token_id=tokenizer.pad_token_id,
                         eos_token_id=tokenizer.eos_token_id)
    return tokenizer.decode(out[0, ids.shape[1]:], skip_special_tokens=True).strip()

def score(rows):
    predictions = [predict(r["text"]) for r in rows]
    return {"accuracy": sum(p == r["label"] for p, r in zip(predictions, rows)) / len(rows),
            "predictions": predictions}

# Save baseline before adapting weights. Test examples are never used to train.
# Baseline and adapter scores are compared once at the end.
model.to("cuda" if torch.cuda.is_available() else
         "mps" if torch.backends.mps.is_available() else "cpu")
baseline = score(splits["test"])
model = get_peft_model(model, LoraConfig(
    task_type="CAUSAL_LM", r=8, lora_alpha=16,
    lora_dropout=0.05, target_modules=["q_proj", "v_proj"],
    bias="none",
))
model.print_trainable_parameters()
args = TrainingArguments(
    output_dir="checkpoints", num_train_epochs=2,
    per_device_train_batch_size=1, per_device_eval_batch_size=1,
    gradient_accumulation_steps=4, learning_rate=2e-4,
    eval_strategy="epoch", save_strategy="epoch",
    load_best_model_at_end=True, metric_for_best_model="eval_loss",
    greater_is_better=False, save_total_limit=2,
    logging_steps=1, report_to="none", optim="adamw_torch",
    seed=42, data_seed=42, label_names=["labels"],
)
trainer = Trainer(model=model, args=args, train_dataset=data["train"],
                  eval_dataset=data["validation"], processing_class=tokenizer)
trainer.train()
model.save_pretrained("adapter")
tokenizer.save_pretrained("adapter")
adapted = score(splits["test"])
report = {"baseline": baseline, "adapted": adapted,
          "test_size": len(splits["test"]),
          "note": "Tiny synthetic demo. Do not infer generalization from this score."}
Path("results.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
