import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

base = AutoModelForCausalLM.from_pretrained(
    "Qwen/Qwen2.5-0.5B-Instruct", torch_dtype=torch.float32
)
model = PeftModel.from_pretrained(base, "adapter")
tokenizer = AutoTokenizer.from_pretrained("adapter")
device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"
model.to(device).eval()
messages = [
    {"role": "system", "content": "Classify the support request. Reply with BILLING, ACCOUNT, or TECHNICAL only."},
    {"role": "user", "content": "I was charged twice this month."},
]
ids = tokenizer.apply_chat_template(messages, tokenize=True,
                                    add_generation_prompt=True, return_tensors="pt").to(device)
with torch.inference_mode():
    output = model.generate(ids, attention_mask=torch.ones_like(ids),
                            max_new_tokens=8, do_sample=False,
                            pad_token_id=tokenizer.eos_token_id)
print(tokenizer.decode(output[0, ids.shape[1]:], skip_special_tokens=True))
